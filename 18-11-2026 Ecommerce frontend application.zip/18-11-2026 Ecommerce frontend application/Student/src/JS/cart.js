
import { products } from './products.js';

export let cart = [];

// Add product to cart
export function addToCart(productId) {

    const product = products.find(item => item.id === productId);

    if (product) {
        cart.push(product);
    }

    document.getElementById("cartCount").textContent = cart.length;

}

// Display cart items
export function displayCart() {

    const cartContainer = document.getElementById("cartContainer");

    cartContainer.innerHTML = "";

    if (cart.length === 0) {
        cartContainer.innerHTML = "<p>Your cart is empty!</p>";
        return;
    }

    cart.forEach(item => {

        cartContainer.innerHTML += `
            <div class="bg-white p-4 rounded-lg shadow mb-4">

                <h3 class="font-bold">${item.name}</h3>

                <p>Price: ₹${item.price}</p>

                <button
                    class="remove-item bg-red-500 text-white px-3 py-2 rounded"
                    data-id="${item.id}">
                    Remove
                </button>

            </div>
        `;

    });

}
