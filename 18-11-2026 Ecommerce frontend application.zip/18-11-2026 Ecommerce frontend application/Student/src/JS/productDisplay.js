
const productContainer = document.getElementById("productContainer");
const productCount = document.getElementById("productCount");

export function displayProducts(productList) {

    // Clear previous products
    productContainer.innerHTML = "";

    // Display each product
    productList.forEach((product) => {

        const productCard = document.createElement("article");

        productCard.className =
            "bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition duration-300";

        productCard.innerHTML = `
            <img
                src="${product.image}"
                alt="${product.name}"
                class="w-full h-48 object-cover"
            >

            <div class="p-5">

                <h3 class="text-lg font-bold">
                    ${product.name}
                </h3>

                <p class="text-gray-500 text-sm mt-2">
                    ${product.description}
                </p>

                <div class="flex justify-between items-center mt-4">

                    <span class="text-xl font-bold text-blue-600">
                        ₹${product.price.toLocaleString("en-IN")}
                    </span>

                    <span class="text-yellow-500">
                        ⭐ ${product.rating}
                    </span>

                </div>

                <button
                    type="button"
                    class="add-to-cart w-full bg-blue-600 text-white py-2 rounded-lg mt-4 hover:bg-blue-700"
                    data-id="${product.id}"
                >
                    Add to Cart
                </button>

            </div>
        `;

        productContainer.appendChild(productCard);

    });

    // Update product count
    productCount.textContent = productList.length;
}
