
export const products = [
    {
        id: 1,
        name: "Wireless Headphones",
        category: "electronics",
        price: 1999,
        rating: 4.5,
        image: "https://placehold.co/300x250?text=Headphones",
        description: "High-quality wireless headphones with excellent sound."
    },
    {
        id: 2,
        name: "Smart Watch",
        category: "electronics",
        price: 2499,
        rating: 4.2,
        image: "https://placehold.co/300x250?text=Smart+Watch",
        description: "Smart watch with fitness tracking features."
    },
    {
        id: 3,
        name: "Men's T-Shirt",
        category: "fashion",
        price: 599,
        rating: 4.0,
        image: "https://placehold.co/300x250?text=T-Shirt",
        description: "Comfortable cotton T-shirt for everyday wear."
    },
    {
        id: 4,
        name: "Running Shoes",
        category: "shoes",
        price: 1799,
        rating: 4.6,
        image: "https://placehold.co/300x250?text=Shoes",
        description: "Lightweight running shoes for daily workouts."
    },
    {
        id: 5,
        name: "Leather Wallet",
        category: "accessories",
        price: 799,
        rating: 4.3,
        image: "https://placehold.co/300x250?text=Wallet",
        description: "Stylish wallet with multiple compartments."
    },
    {
        id: 6,
        name: "Bluetooth Speaker",
        category: "electronics",
        price: 1499,
        rating: 4.4,
        image: "https://placehold.co/300x250?text=Speaker",
        description: "Portable speaker with powerful sound."
    },
    {
        id: 7,
        name: "Women's Handbag",
        category: "fashion",
        price: 1299,
        rating: 4.7,
        image: "https://placehold.co/300x250?text=Handbag",
        description: "Elegant handbag for everyday use."
    },
    {
        id: 8,
        name: "Sports Shoes",
        category: "shoes",
        price: 2199,
        rating: 4.5,
        image: "https://placehold.co/300x250?text=Sports+Shoes",
        description: "Comfortable shoes for sports and fitness."
    },
    {
        id: 9,
        name: "Sunglasses",
        category: "accessories",
        price: 499,
        rating: 4.1,
        image: "https://placehold.co/300x250?text=Sunglasses",
        description: "Modern sunglasses with a stylish design."
    },
    {
        id: 10,
        name: "Laptop",
        category: "electronics",
        price: 45999,
        rating: 4.8,
        image: "https://placehold.co/300x250?text=Laptop",
        description: "Powerful laptop for work and entertainment."
    },
    {
        id: 11,
        name: "Casual Shirt",
        category: "fashion",
        price: 899,
        rating: 4.2,
        image: "https://placehold.co/300x250?text=Shirt",
        description: "Casual shirt suitable for everyday occasions."
    },
    {
        id: 12,
        name: "Smart Watch Strap",
        category: "accessories",
        price: 399,
        rating: 4.0,
        image: "https://placehold.co/300x250?text=Watch+Strap",
        description: "Comfortable replacement strap for smart watches."
    }
];
