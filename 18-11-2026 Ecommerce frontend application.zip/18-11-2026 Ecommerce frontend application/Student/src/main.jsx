
import './index.css';
import { products } from './products';
import { displayProducts } from './JS/productDisplay';
import { displayCart } from './JS/cart';
import { addToCart } from './JS/cart';
// Initial display
displayProducts(products);
// Add to Cart
document.getElementById("productContainer").addEventListener("click", (event) => {

    const button = event.target.closest(".add-to-cart");

    if (button) {
        addToCart(Number(button.dataset.id));
    }

});

// Open Cart
document.getElementById("cartBtn").addEventListener("click", () => {

    document.getElementById("cartSection").classList.toggle("hidden");

    displayCart();
    
        cartSection.scrollIntoView({
        behavior: "smooth",
        block: "start"
    });

});